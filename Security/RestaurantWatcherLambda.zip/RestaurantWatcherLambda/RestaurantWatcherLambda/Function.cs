using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using Amazon.S3;

using Amazon.S3.Model;
using System.Threading;
using System.IO;
using System.Text;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace RestaurantWatcherLambda
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        /// 
        public IAmazonS3 client;
        public async Task FunctionHandler(ILambdaContext context)
        {
            StringBuilder emailBody = new StringBuilder();
            using (client = new AmazonS3Client("", "", RegionEndpoint.USEast1))
            {
                //uncomment follwoing code when need to refresh server file
                string webInterfaceBucket = "";
               string configBucket = "";

                // comment following method call once server state has been saved
                await RefreshFilesInfo(webInterfaceBucket, context);

                emailBody.Append(await ProcessWebServerForensics(configBucket, context));

                SendEmailFromGmail(emailBody.ToString());               
            }
        }

        private async Task RefreshFilesInfo(string bucketName, ILambdaContext context)
        {
            try
            {
                ListObjectsRequest listObjectsRequest = new ListObjectsRequest();
                listObjectsRequest.BucketName = bucketName;

                ListObjectsResponse listObjectsResponse = await client.ListObjectsAsync(listObjectsRequest);
                string dest = "/tmp/FileScan.txt";

                File.WriteAllText(dest, "");

                foreach (S3Object entry in listObjectsResponse.S3Objects)
                {
                    Console.WriteLine("key = {0} size = {1}", entry.Key, entry.Size);

                    GetObjectRequest getObjectRequest = new GetObjectRequest()
                    {
                        BucketName = bucketName,
                        Key = entry.Key
                    };

                    using (GetObjectResponse response = await client.GetObjectAsync(getObjectRequest))
                    {
                        GetACLResponse acl = await client.GetACLAsync(bucketName);
                        S3AccessControlList s3AccessControlList = acl.AccessControlList;

                        Files file = new Files()
                        {
                            FileName = response.Key,
                            FileSize = listObjectsResponse.S3Objects.Count,
                            FileOwner = bucketName,
                            ContentLength = response.ContentLength.ToString(),
                            CreatedDate = DateTime.Now,
                            EncryptionMethod = response.ServerSideEncryptionMethod,
                            ServerSideEncryptionKeyManagementServiceKeyId = response.ServerSideEncryptionKeyManagementServiceKeyId,
                            LastModifiedDateTime = response.LastModified,
                            ContentType = response.Headers.ContentType,
                            MetaDataCount = response.Metadata.Count,
                            ETag = response.ETag, // ETag can be used as MD5
                            VersionId = response.VersionId,
                            Expires = response.Metadata["x-amz-meta-expires"] ?? null,
                            StorageClass = response.StorageClass?.Value,
                            ContentMD5 = response.Headers.ContentMD5,
                            CacheControl = response.Headers.CacheControl,
                            ProprietaryMark = response.Metadata["x-amz-meta-proprietary-mark"] ?? null,
                            AccessControlCount = s3AccessControlList.Grants.Count,
                            AccessControlOwner = s3AccessControlList.Owner.DisplayName
                        };

                        string jsonFile = JsonConvert.SerializeObject(file);
                        File.AppendAllText(dest, Environment.NewLine + jsonFile);
                    }
                }

                PutObjectRequest putObjectRequest = new PutObjectRequest()
                {
                    BucketName = "",
                    Key = "FileScan.txt",
                    FilePath = dest
                };

                PutObjectResponse putObjectResponse = await client.PutObjectAsync(putObjectRequest);

            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId") ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    Console.WriteLine("Please check the provided AWS Credentials.");
                    Console.WriteLine("If you haven't signed up for Amazon S3, please visit http://aws.amazon.com/s3");
                }
                else
                {
                    Console.WriteLine("An Error, number {0}, occurred when listing buckets with the message '{1}", amazonS3Exception.ErrorCode, amazonS3Exception.Message);
                }
            }

        }

        private async Task<StringBuilder> ProcessWebServerForensics(string bucketName, ILambdaContext context)
        {
            string dest = "/tmp/FileScan.txt";

            context.Logger.LogLine("Calling process web server");

            // Define the cancellation token.
            CancellationTokenSource source = new CancellationTokenSource();
            CancellationToken token = source.Token;

            // Get the saved state

            GetObjectRequest request = new GetObjectRequest()
            {
                BucketName = bucketName,
                Key = "FileScan.txt"
            };

            // Define the cancellation token.
            source = new CancellationTokenSource();
            token = source.Token;

            List<Files> fileList = new List<Files>();
            using (GetObjectResponse response = await client.GetObjectAsync(request))
            {
               await response.WriteResponseStreamToFileAsync(dest, false, token);
            }

            context.Logger.LogLine("Writing file");

            List<string> jsonFileList = new List<string>();
            jsonFileList = File.ReadAllLines(dest).ToList();
            jsonFileList = jsonFileList.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();

            foreach (string jsonScan in jsonFileList)
            {
                fileList.Add(Newtonsoft.Json.JsonConvert.DeserializeObject<Files>(jsonScan));
            }

            // Now get compare with the live files

            ListObjectsRequest listObjectsRequest = new ListObjectsRequest();
            listObjectsRequest.BucketName = fileList[0].FileOwner;

            ListObjectsResponse listObjectsResponse = await client.ListObjectsAsync(listObjectsRequest);

            int index = 0;
            StringBuilder myString = new StringBuilder("<h3>Web Server:</h3><p>");
            bool isWebServerCompromised = false;

            context.Logger.LogLine("before loop");

            foreach (S3Object entry in listObjectsResponse.S3Objects)
            {
                Console.WriteLine("key = {0} size = {1}", entry.Key, entry.Size);

                GetObjectRequest getObjectRequest = new GetObjectRequest()
                {
                    BucketName = fileList[0].FileOwner,
                    Key = entry.Key
                };

                using (GetObjectResponse response = await client.GetObjectAsync(getObjectRequest))
                {
                    GetACLResponse acl = await client.GetACLAsync(fileList[0].FileOwner);
                    S3AccessControlList s3AccessControlList = acl.AccessControlList;

                    myString.Append("<h4>File Name: " + fileList[index].FileName + "</h4>");


                    myString.Append("<b>Compare: Saved State - Live Version</b>");

                    if (fileList[index].FileName == response.Key)
                    {
                        myString.Append("<br>File Name:  <font color='green'>" + fileList[index].FileName + " - " + response.Key + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>File Name:  <font color='green'>" + fileList[index].FileName + "</font> - <font color='red'>" + response.Key + "</font>");
                    }

                    if (fileList[index].ContentLength == response.ContentLength.ToString())
                    {
                        myString.Append("<br>Content Length:  <font color='green'>" + fileList[index].ContentLength + " - " + response.ContentLength.ToString() + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>Content Length:  <font color='green'>" + fileList[index].ContentLength + "</font> - <font color='red'>" + response.ContentLength.ToString() + "</font>");
                    }

                    if (fileList[index].MetaDataCount == response.Metadata.Count)
                    {
                        myString.Append("<br>MetaData Count:  <font color='green'>" + fileList[index].MetaDataCount + " - " + response.Metadata.Count.ToString() + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>MetaData Count  <font color='green'>" + fileList[index].MetaDataCount + "</font> - <font color='red'>" + response.Metadata.Count.ToString() + "</font>");
                    }

                    //fileList[index].ETag


                    if (fileList[index].ETag == response.ETag)
                    {
                        myString.Append("<br>ETag:  <font color='green'>" + fileList[index].ETag + " - " + response.ETag + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>ETag:  <font color='green'>" + fileList[index].ETag + "</font> - <font color='red'>" + response.ETag + "</font>");
                    }
     
               
                    // fileList[index].CacheControl


                    if (fileList[index].CacheControl == response.Headers.CacheControl)
                    {
                        myString.Append("<br>Cache Control:  <font color='green'>" + fileList[index].CacheControl + " - " + response.Headers.CacheControl + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>Cache Control:  <font color='green'>" + fileList[index].CacheControl + "</font> - <font color='red'>" + response.Headers.CacheControl + "</font>");
                    }

                    
                    if (fileList[index].AccessControlCount == s3AccessControlList.Grants.Count)
                    {
                        myString.Append("<br>Access Control Count:  <font color='green'>" + fileList[index].AccessControlCount.ToString() + " - " + s3AccessControlList.Grants.Count.ToString() + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>Access Control Count:  <font color='green'>" + fileList[index].AccessControlCount.ToString() + "</font> - <font color='red'>" + s3AccessControlList.Grants.Count.ToString() + "</font>");
                    }



                    if (fileList[index].AccessControlOwner == s3AccessControlList.Owner.DisplayName)
                    {
                        myString.Append("<br>Access Control Owner:  <font color='green'>" + fileList[index].AccessControlOwner + " - " + s3AccessControlList.Owner.DisplayName + "</font>");
                    }
                    else
                    {
                        isWebServerCompromised = true;
                        myString.Append("<br>Access Control Owner:  <font color='green'>" + fileList[index].AccessControlOwner + "</font> - <font color='red'>" + s3AccessControlList.Owner.DisplayName + "</font>");
                    }

                }

                index++;
            }

            // context.Logger.LogLine("before start : " + myString.ToString());

            context.Logger.LogLine("before server compromised");

            if (isWebServerCompromised)
            {

                //context.Logger.LogLine("isWebServerCompromised start : ");

                // Create new bucket and copy contents


                myString.Append("<h3><font color='red'>Web Server Compromised:</font></h3><p>");

                myString.Append("<h5>Web Server has been compromised</h5><p>");


            }

            context.Logger.LogLine(myString.ToString());
            
            return myString.Append("</p>");
        }

        // From AWS sample
        static bool SendEmailFromGmail(string body)
        {

            const String FROM = "restaurantfinderproject@gmail.com";
            const String FROMNAME = "Restaurant Finder - Cloud Computing";

            // Replace recipient@example.com with a "To" address. If your account 
            // is still in the sandbox, this address must be verified.
            const String TO = "restaurantfinderproject@gmail.com";

            // Replace smtp_username with your Amazon SES SMTP user name.
            const String SMTP_USERNAME = "";

            // Replace smtp_password with your Amazon SES SMTP user name.
            const String SMTP_PASSWORD = "";

            // (Optional) the name of a configuration set to use for this message.
            // If you comment out this line, you also need to remove or comment out
            // the "X-SES-CONFIGURATION-SET" header below.
            //const String CONFIGSET = "ConfigSet";

            // If you're using Amazon SES in a region other than US West (Oregon), 
            // replace email-smtp.us-west-2.amazonaws.com with the Amazon SES SMTP  
            // endpoint in the appropriate Region.
            //const String HOST = "email-smtp.us-east-1.amazonaws.com";
            const String HOST = "smtp.gmail.com";
            // The port you will connect to on the Amazon SES SMTP endpoint. We
            // are choosing port 587 because we will use STARTTLS to encrypt
            // the connection.
            const int PORT = 587;

            // The subject line of the email
            const String SUBJECT =
                "Restaurant Finder";

            // The body of the email
            string BODY = body;

            // Create and build a new MailMessage object
            MailMessage message = new MailMessage()
            {

            };
            message.IsBodyHtml = true;
            message.From = new MailAddress(FROM, FROMNAME);
            message.To.Add(new MailAddress(TO));
            message.Subject = SUBJECT;
            message.Body = BODY;


            // Comment or delete the next line if you are not using a configuration set
            //message.Headers.Add("X-SES-CONFIGURATION-SET", CONFIGSET);

            // Create and configure a new SmtpClient
            SmtpClient client =
                new SmtpClient(HOST, PORT);
            // Pass SMTP credentials
            client.Credentials =
                new NetworkCredential(SMTP_USERNAME, SMTP_PASSWORD);
            // Enable SSL encryption
            client.EnableSsl = true;

            // Send the email. 
            try
            {
                Console.WriteLine("Attempting to send email...");
                client.Send(message);
                Console.WriteLine("Email sent!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("The email was not sent.");
                Console.WriteLine("Error message: " + ex.Message);
                return false;
            }

            // Wait for a key press so that you can see the console output
            // Console.Write("Press any key to continue...");
            // Console.ReadKey();
            //return input?.ToUpper();
            return true;
        }

        // From AWS sample
        private bool SendEmail(string body)
        {

            const String FROM = "salman.rashid@gmail.com";
            const String FROMNAME = "Restaurant Finder - Cloud Computing";

            // Replace recipient@example.com with a "To" address. If your account 
            // is still in the sandbox, this address must be verified.
            const String TO = "restaurantfinderproject@gmail.com";

            // Replace smtp_username with your Amazon SES SMTP user name.
            const String SMTP_USERNAME = "";

            // Replace smtp_password with your Amazon SES SMTP user name.
            const String SMTP_PASSWORD = "";

            // (Optional) the name of a configuration set to use for this message.
            // If you comment out this line, you also need to remove or comment out
            // the "X-SES-CONFIGURATION-SET" header below.
            //const String CONFIGSET = "ConfigSet";

            // If you're using Amazon SES in a region other than US West (Oregon), 
            // replace email-smtp.us-west-2.amazonaws.com with the Amazon SES SMTP  
            // endpoint in the appropriate Region.
            const String HOST = "email-smtp.us-east-1.amazonaws.com";

            // The port you will connect to on the Amazon SES SMTP endpoint. We
            // are choosing port 587 because we will use STARTTLS to encrypt
            // the connection.
            const int PORT = 587;

            // The subject line of the email
            const String SUBJECT =
                "Restaurant Finder";

            // The body of the email
            string BODY = body;

            // Create and build a new MailMessage object
            MailMessage message = new MailMessage()
            {

            };
            message.IsBodyHtml = true;
            message.From = new MailAddress(FROM, FROMNAME);
            message.To.Add(new MailAddress(TO));
            message.Subject = SUBJECT;
            message.Body = BODY;


            // Comment or delete the next line if you are not using a configuration set
            //message.Headers.Add("X-SES-CONFIGURATION-SET", CONFIGSET);

            // Create and configure a new SmtpClient
            SmtpClient client =
                new SmtpClient(HOST, PORT);
            // Pass SMTP credentials
            client.Credentials =
                new NetworkCredential(SMTP_USERNAME, SMTP_PASSWORD);
            // Enable SSL encryption
            client.EnableSsl = true;

            // Send the email. 
            try
            {
                Console.WriteLine("Attempting to send email...");
                client.Send(message);
                Console.WriteLine("Email sent!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("The email was not sent.");
                Console.WriteLine("Error message: " + ex.Message);
                return false;
            }

            // Wait for a key press so that you can see the console output
            // Console.Write("Press any key to continue...");
            // Console.ReadKey();
            //return input?.ToUpper();
            return true;
        }
    }
}
