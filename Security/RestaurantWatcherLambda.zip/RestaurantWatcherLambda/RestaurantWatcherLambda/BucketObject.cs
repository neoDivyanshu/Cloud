﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantWatcherLambda
{
 

    class Files
    {
        public int FileId { get; set; }
        public string FileOwner { get; set; } 
        public string FileName { get; set; }
        public string ContentMD5 { get; set; }
        public int FileSize { get; set; } 
        public string ContentType { get; set; }
        public int MetaDataCount { get; set; }
        public string ETag { get; set; }
        public string ContentLength { get; set; }
        public string VersionId { get; set; }
        public string FileContent { get; set; }
        public string StorageClass { get; set; }
        public string CacheControl { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string Expires { get; set; }
        public string ProprietaryMark { get; set; }
        public int AccessControlCount { get; set; }
        public string AccessControlOwner { get; set; }
        public bool IsBucketLoggingEnabled { get; set; }
        public bool IsEncryptionEnabled { get; set; }
        public string ServerSideEncryptionKeyManagementServiceKeyId { get; set; }
        public string EncryptionMethod { get; set; }
        public DateTime? LastModifiedDateTime { get; set; }
    }

    class Bucket
    {
        public int BucketId { get; set; }
        public string BucketOwner { get; set; }
        public string BucketName { get; set; }
        public string ServerSideEncryption { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? LastModifiedDateTime { get; set; }
    }

    class User
    {
        public string UserName { get; set; }
        public string Email { get; set; }        
        public string HashedPassword { get; set; }
        public DateTime? LastSuccessfulLoginDateTime { get; set; }
        public int FailedAttempts { get; set; }
        public bool IsUserBlocked { get; set; }
        public bool? IsUserBlockedEmailSent { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public User()
        {
            UserName = "";
            Email = "";
            HashedPassword = "";
            LastSuccessfulLoginDateTime = DateTime.Now;
            FailedAttempts = 0;
            IsUserBlocked = false;
            CreatedDateTime = null;
            UpdatedDateTime = null;
            IsUserBlockedEmailSent = null;
        }
    }

  
    class Log
    {
        public string UserName { get; set; }
        public string ClientPublicIP { get; set; }
        public string ClientEndPointIP { get; set; }
        public string ActionTaken { get; set; }
        public string BucketAccessed { get; set; }
        public string FileAccessed { get; set; }
        public string MD5 { get; set; }
        public DateTime RequestDateTime { get; set; }
        public bool IsLogProcessed { get; set; }
        public DateTime? ProcessedDateTime { get; set; }

        public Log()
        {     
            IsLogProcessed = false;            
            ProcessedDateTime = DateTime.Now;
        }
    }

    class Scan
    {
        public DateTime ScanTimeStamp { get; set; }
        public DateTime? SavedStateTimeStamp { get; set; }
        public string WwwrootDirectory { get; set; }
        int FileCount { get; set; }
        public bool IsFileName { get; set; }
        public bool IsContentLength { get; set; }
        public bool IsMetaDataCount { get; set; }
        public bool IsETag { get; set; }
        public bool IsVersionId { get; set; }
        public bool IsCacheControl { get; set; }
        public bool IsProprietaryMark { get; set; }
        public bool IsAccessControlCount { get; set; }
        public bool IsAccessControlOwner { get; set; }

        public Scan()
        {
            FileCount = 3;
            ScanTimeStamp = DateTime.Now;
            IsFileName = true;
            IsContentLength = true;
            IsMetaDataCount = true;
            IsETag = true;
            IsVersionId = true;
            IsCacheControl = true;
            IsProprietaryMark = true;
            IsAccessControlCount = true;
            IsAccessControlOwner = true;
        }

    }
}
